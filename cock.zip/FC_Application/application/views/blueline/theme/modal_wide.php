 <div class="modal-dialog wide">
    <div class="modal-content">
      
      <div class="modal-body">
                    
        <?=$yield?>         

     
    </div>
  </div>
