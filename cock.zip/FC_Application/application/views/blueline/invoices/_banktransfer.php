

         <div class="form-group">
        <?= $core_settings->bank_transfer_text;?>
        </div>

        
        <div class="modal-footer">
         <a class="btn" data-dismiss="modal"><?=$this->lang->line('application_close');?></a>
        </div>



