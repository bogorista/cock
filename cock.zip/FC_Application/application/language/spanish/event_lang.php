<?php

$lang['event_invoice_overdue'] = 'Pago de factura  es {invoice_number} <span class="label label-important"> atrasado </span>';

$lang['event_project_overdue'] = 'Proyecto {project_number} <span class="label label-important">plazo llegado</span>';

$lang['event_subscription_new_invoice'] = '<span class="label label-warning">factura nueva</span> se requiere para la suscripción {subscription_number}';



