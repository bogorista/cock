<?php

class Privatemessage extends ActiveRecord\Model {

}
