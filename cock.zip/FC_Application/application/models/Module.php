<?php

class Module extends ActiveRecord\Model {

}
